# Task6: Percentiles and Sorting
import numpy as np
marks =np.array(sorted([78,85,90,72,88,95,60]))

print("25th percentile",np.percentile(marks,25))
print("50th percentile",np.percentile(marks,50))
print("75th percentile",np.percentile(marks,75))
print("Number of student above average marks : ", len(marks[marks>marks.mean()]))