# Task4: Aggregation Operations

import numpy as np

data =np.array([
    [10,20,30],
    [40,50,60],
    [70,80,90]
])

print(data.sum(axis=1))
print(data.sum(axis=0))
print(data.max())
print(data.min())
print(data.mean())