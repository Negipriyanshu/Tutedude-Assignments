# Task5 : Statistical Operations

import numpy as np
marks =np.array([78,85,90,72,88,95,60])

print("Mean : ",marks.mean())
print("Median : ",np.median(marks))
print("Variance : ",np.var(marks))
print("Standard Deviation : ",np.std(marks))
print("Minimum : ",np.min(marks)," Maximum : ",np.max(marks))
print("Range : ",np.max(marks) - np.min(marks))