# Task1: Create numpy arrays
import numpy as np

arr_1d=np.arange(1,11)

arr_2d =np.arange(1,10).reshape(3,3)

lst = [10,20,30,40,50]
arr_from_list = np.array(lst)

print(f"Shape of 1D Array : {arr_1d.shape} and Datatype is {arr_1d.dtype}\nShape of 2D Array : {arr_2d.shape} and Datatype is {arr_2d.dtype}\nShape of Array from list : {arr_from_list.shape} and Datatype is {arr_from_list.dtype}")