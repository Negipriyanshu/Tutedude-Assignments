# Task7: Mini Use Case: Sales Analysis
import numpy as np
sales = np.array([1200,1500,900,2000,1800,1700,1600])

print("Total Weekly Sales : ",np.sum(sales))
print("Average daily sales : ",np.average(sales))
print(f"Highest Sales day : {np.max(sales)} and Lowest Sales day : {np.min(sales)}")
print(f"Standard Deviation of Sales : {np.std(sales)}")
print(sales[sales > np.average(sales)])