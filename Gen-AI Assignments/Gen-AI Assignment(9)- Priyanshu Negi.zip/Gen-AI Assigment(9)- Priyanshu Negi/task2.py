# Task2: Important MAthematical Operations

import numpy as np
A=np.array([10,20,30,40])
B=np.array([1,2,3,4])

print(f"Addition : {A+B}")
print(f"Subtraction : {A-B}")
print(f"Multiplication : {A*B}")
print(f"Power : {A**2}")