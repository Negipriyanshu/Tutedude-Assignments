# Task3: Important Numpy Mathematical Formulas

import numpy as np

values =np.array([2,4,6,8,10])
print(f"Square root : {np.sqrt(values)}")
print(f"Exponential : {np.exp(values)}")
print(f"Natural Log. : {np.log(values)}")
print(f"Sum : {np.sum(values)}")
print(f"Cumulative sum : {np.cumsum(values)}")
