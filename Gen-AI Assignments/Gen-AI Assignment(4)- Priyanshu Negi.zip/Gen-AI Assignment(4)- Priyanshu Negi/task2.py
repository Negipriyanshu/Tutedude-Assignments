# Task 2: Read File in Different ways
with open('sales_data.txt','r') as file:
    # 1. read entire file using .read()
    print(file.read())
    file.seek(0)
    # 2. read first line using .readline()
    print(file.readline())
    file.seek(0)
    # 3. read all line using ,.readlines() and convert them into a list of integers.
    data =[int(line.strip()) for line in file.readlines()]
    print(data)