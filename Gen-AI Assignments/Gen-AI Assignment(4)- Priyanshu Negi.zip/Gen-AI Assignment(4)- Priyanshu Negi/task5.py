# Task 5: Create Product info file(User input)
'''
1. Ask the user for 3product names and their prices.
2. Write them into a new file products.txt in this format:
3. ProductName | Price
4. Read the File and Print each line with proper formatting
'''
with open("products.txt",'w+') as file:
    file.write("ProductName | Price \n")
    for i in range(3):
        product =input("Enter the Product name : ")
        price = input("Enter the price of the product : ")
        file.write(f"{product} | {price} \n")
    file.seek(0)
    data = [i.strip() for i in file.readlines()]

# 4. Read the File and Print each line with proper formatting
for i in data:
    print(i)