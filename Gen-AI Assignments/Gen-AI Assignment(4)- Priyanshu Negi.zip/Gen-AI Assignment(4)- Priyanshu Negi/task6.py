# Task 6: Read File Safety (Error Handling Inside File Handling only)
'''
You must not use exceptions beyond file-related safeguards here.
1. Ask user for a filename to open.
2. if the file exists, read and print it.
3. if it does not exist, print:
"File Not Found. Please Check the file name."
'''
import os
file_name = input("Enter the file name \n")
if os.path.exists(file_name):
    with open(file_name,'r') as file:
        print(file.read())
else:
    print("File Not Found. Please Check the file name.")