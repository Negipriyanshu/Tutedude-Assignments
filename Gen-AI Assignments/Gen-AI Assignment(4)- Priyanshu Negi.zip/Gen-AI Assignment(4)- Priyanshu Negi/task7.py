# Task 7: Mini Project - Export Discount Prices
'''
Create a dictionary:
prices={
    "Mouse":500,
    "Keyboard":800,
    "Monitor":7000,
    "Pendrive":400,
    "Camera":5000
}
Ask the user for a discount percentage.
write discounted price into discount_report.txt using:
Product | Original Price | Discounted Price
Afteer writing, read the file and print it to the terminal.
Extra(optional) : Write summary at the bottom of the file:
total items: X
Average Discounted Price: Y
'''

prices={
    "Mouse":500,
    "Keyboard":800,
    "Monitor":7000,
    "Pendrive":400,
    "Camera":5000
}
discount = int(input("Enter the discount percentage : \n"))
with open("discount_report.txt","w") as file:
    file.write("Product | Original Price | Discounted Price \n")
    total_dis_price = 0
    for i in prices:
        product = i
        price = str(prices[i])
        discount_price = prices[i] - (prices[i]*discount)/100
        total_dis_price = total_dis_price +discount_price
        file.write(f"{product} | {price} | {str(discount_price)}\n")
    file.write(f"\nSummary \nTotal items : {str(len(prices))} \nAverage Discounted Price : {total_dis_price/len(prices)}")

with open("discount_report.txt","r") as file:
    print(file.read())