# Task 3: Append New Sales

# 1. Append new sales to same file: 5000,2500,1700
new_sales =[5000,2500,1700]
with open('sales_data.txt','a') as file:
    for sale in new_sales:
        file.write(f"{str(sale)}\n")
    

# 2.After appending,reopen and print the entire updated file
with open('sales_data.txt','r') as file:
    print(file.read())
    
# Extra(optional) : number of lines after appending
def count_line(file):
    with open('sales_data.txt','r') as file:
        lines =file.readlines()
        return len(lines)
    
with open('sales_data.txt','r') as file:
    print(f"No. of line are : {count_line(file)}")