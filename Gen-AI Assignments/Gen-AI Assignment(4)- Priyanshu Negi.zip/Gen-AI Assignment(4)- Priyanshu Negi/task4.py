# Task 4: Generate Summary Report From file
'''
Using  only file reading operations:
1. Read all sales values from sales_data.txt
2. Convert them into integers.
3. Calculate and print.
    Total sales, Highest Sale, Lowest Sale, Average Sale
'''
with open('sales_data.txt','r') as file:
    data =file.readlines()

data = [int(i.strip()) for i in data]

print(f"Total Sales : {sum(data)} \nHighest Sales : {max(data)} \nLowest Sales : {min(data)} \nAverage Sales : {sum(data)/len(data)}")