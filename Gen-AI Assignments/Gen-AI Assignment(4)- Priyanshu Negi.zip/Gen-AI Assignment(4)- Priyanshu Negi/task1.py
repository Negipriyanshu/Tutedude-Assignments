# Task 1: Write Sales Records to a File

sales =[1200,450,980,1500,3000]
with open('sales_data.txt','w') as file:
    for sale in sales:
        file.write(f"{str(sale)}\n")
    
with open('C:/Coding/DataScience TuteDude/GenAI/Gen-AI Assignment(4)- Priyanshu Negi/sales_data.txt','r') as file:
    print(file.read())
