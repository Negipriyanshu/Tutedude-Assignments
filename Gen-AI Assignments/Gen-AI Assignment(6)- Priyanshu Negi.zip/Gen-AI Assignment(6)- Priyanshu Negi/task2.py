# Task2: Bill Calculator with Error Handling
prices =[120,350,'abc',500,-200,800]

total =0
for i in prices:
    try:
        # Check type
        if not isinstance(i,(int,float)):
            raise TypeError("Value is not number...")

        # custom exception
        if i <0:
            raise ValueError("Negative Price not allowed")
            
        total =total + i
        print("Running total : ",total)
        
    except TypeError as e:
        print(f"Skipped {i} -> {e}")
    except ValueError as e:
        print(f"Skipped {i} -> {e}")

print("\n Final Total: ",total)