# Mini Program: Safe Shopping Cart

cart =[]

while True :
    try:
        price =input("Enter the price(q for quit) \n")
    
        if price == 'q':
            break
        elif int(price) <0:
            raise ValueError("price is negative")
        else: 
            cart.append(float(price))
    except ValueError:
        print("user enter invalid input")
print("Total items : ",len(cart),"\n Final Total : ",sum(cart))