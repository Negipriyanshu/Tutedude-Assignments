try :
    num = int(input("Enter the numerator \n"))
    den =int(input("Enter the denominator :\n"))
    
    result =num/den

except ValueError as e:
    print(e)      
except ZeroDivisionError as e:
    print(e)
else:
    print(result)
finally:
    print("Operation Complete")