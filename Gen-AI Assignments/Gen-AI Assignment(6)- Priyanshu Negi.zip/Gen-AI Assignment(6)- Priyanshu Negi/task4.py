#  Task4: File Reader with Exception Handling
try:
    file = input("Enter the file name: \n")
    
    with open(file,"r") as file:
        data =file.readlines()
        for i in data[:3]:
            print(i.strip())
        
except FileNotFoundError as e:
    print(e)
except PermissionError as e:
    print(e)
finally: 
    print("File operation attempted.")