# Task3: Custom Exception: Age Validator

def check_age(age):
    if 1<age<120:
        print("Age : ",age)
    else:
        raise ValueError("Age must be between 1 and 120")
        
try:
    age =int(input("Enter the age :\n"))
    check_age(age)
except ValueError as e:
    print(f"Age is above 120 or below 1")