import Math_utils
from Math_utils import square
print("-----------------------------------------------------")
# Test the functions
print(Math_utils.add(2,3))
print(Math_utils.subtract(5,3))
print(square(5))

print("-----------------------------------------------------")
from string_utils import capitalize_words,reverse_string,word_count
text = "hello welcome to tutedude gen-ai course"
print(capitalize_words(text))
print(reverse_string(text))
print(word_count(text))

print("-----------------------------------------------------")
# Task 4: import package in main.py

import shop_package.discount as disc
from shop_package.billing import calculate_total
import shop_package.billing as bill

price =1000
print("Price after discount : ",disc.apply_discount(price,15))
print("price after flat discount : ",disc.flat_discount(price))

print(bill.apply_tax(10000))
print(calculate_total([100,200,300]))

print("-----------------------------------------------------")