# Task2: Create Another Module(string_utils.py)

def capitalize_words(text):
    return text.title()

def reverse_string(text):
    return text[::-1]

def word_count(text):
    return len(text)