# Task3: Create a simple package(shop_package)

def apply_discount(price,percent):
    return (price - (price*percent)/100)

def flat_discount(price):
    return price-50