# Task1: Create simple module(math_utils.py)
def add(a,b):
    return a+b
def subtract(a,b):
    return a-b
def square(n):
    return n**2
