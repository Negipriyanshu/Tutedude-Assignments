# Task 2 : Categories (Sets)
print("------------------------------------------------------------------------------------------")
product_list =['Nike Air','Asus Tuf','Adidas X Predator','Tropicana Fruit Juice','Parle-G Biscuits','DiaryMilk Silk']

# Creating parallel category list
categories_list = ['Shoes', 'Laptop', 'Shoes', 'Beverages', 'Biscuits', 'Chocolate bar', 'Gaming', 'Gaming']

# 1. Creating category set
categories_set = set(categories_list)
print(categories_set)
print("------------------------------------------------------------------------------------------")
# 2. Add new Category to set and show thst duplicates are ignored.
categories_set.add("Clothes")

print("no. of categories in list : ",len(categories_list) ," \n no. of category in set : ",len(categories_set)) # Thus shows duplicate value are ignored
print("------------------------------------------------------------------------------------------")
# 3. Check category exist or not
category =input("Enter the name of category : \n")
if category in categories_set:
    print(True)
else:
    print(False)
print("------------------------------------------------------------------------------------------")