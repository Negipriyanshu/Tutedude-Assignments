# Task 3 : Product Pricing (Dictionaries)


product_list =['Nike Air','Asus Tuf','Adidas X Predator','Tropicana Fruit Juice','Parle-G Biscuits','DiaryMilk Silk']
price_list =[10000,70000,8000,300,50,150,50000,60000]

print("------------------------------------------------------------------------------------------")
# 1. Create dictionary price_dict where key = product name and values are price.
price_dict =dict(zip(tuple(product_list),tuple(price_list)))
print(price_dict)
print("------------------------------------------------------------------------------------------")
# 2. Add new product with price to price dict
#  - update price of existing product
#  - remove product by name

price_dict["Lays Chips"] = 50

key ="Asus Tuf"
if key in price_dict.keys():
    price_dict[key] = 80000
    
del price_dict["Adidas X Predator"]
print("------------------------------------------------------------------------------------------")
# 3. Print average price of all products with both maximum and minimum prices
sum =0
for i in price_dict.values():
    sum =sum +i

print("average of all products is : ", sum/len(price_dict.keys()))

max_value = max(price_dict.values())
min_value = min(price_dict.values())
for i in price_dict:
    if price_dict[i] == max_value:
        print("product name is : ",i,"maximum value is :",max_value)
    elif price_dict[i]==min_value:
        print("product name is : ",i,"minmum value is :",min_value)
print("------------------------------------------------------------------------------------------")