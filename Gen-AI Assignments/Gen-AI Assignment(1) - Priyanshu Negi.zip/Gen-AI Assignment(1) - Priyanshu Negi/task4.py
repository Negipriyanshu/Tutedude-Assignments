# Task4 : Combined Operations


print("------------------------------------------------------------------------------------------")
# 1. using product list and price_dict, create a list of tuple named catalog where each tuple is (product_name,price, category).
product_list =['Nike Air','Asus Tuf','Adidas X Predator','Tropicana Fruit Juice','Parle-G Biscuits','DiaryMilk Silk']
category_list = ['Shoes', 'Laptop', 'Shoes', 'Beverages', 'Biscuits', 'Chocolate bar']
price_list =[10000,70000,8000,300,50,150,50000,60000]

#  Create dictionary price_dict where key = product name and values are price.
price_dict =dict(zip(tuple(product_list),tuple(price_list)))

catalog=[]
count=0
for i in price_dict:
    catalog.append((i,price_dict[i],category_list[count]))
    count +=1

print(catalog)

print("------------------------------------------------------------------------------------------")

#  2. From catalog, create a new dictionary category_to_products that maps each category to a list of product names in that category
category_to_products =dict()
for product,price,category in catalog:
    if category not in category_to_products:
        category_to_products[category] = []
        
    category_to_products[category].append(product)
print(category_to_products)

print("------------------------------------------------------------------------------------------")

# 3. print all products that belong to the category that has maximum number of products
max_count = 0
max_category =""
for i in category_to_products:
    if max_count < len(category_to_products[i]):
        max_count=len(category_to_products[i])
        max_category= i

print("Category : ",max_category)
print(category_to_products[max_category])

print("------------------------------------------------------------------------------------------")