# Task1 : Product collections(list & tuples)
print("------------------------------------------------------------------------------------------")
# 1. creating a list named products containing at least 6 product names

product_list =['Nike Air','Asus Tuf','Adidas X Predator','Tropicana Fruit Juice','Parle-G Biscuits','DiaryMilk Silk']
print(product_list)
print("------------------------------------------------------------------------------------------")
# 2. create a tuple named sample_product that stores (product_name,price, category) for one product

sample_product =(product_list[2], 6000, "Shoes")
print(sample_product)

print("------------------------------------------------------------------------------------------")
# 3. print the 2nd and lastproduct from the product list.

print("Second Product is : ",product_list[1], " and Last product is : ",product_list[-1])
# Second Product is :  Asus Tuf  and Last product is :  DiaryMilk Silk
print("------------------------------------------------------------------------------------------")
# 4. Append 2 new product names to products and then print the updated list.
product_list.append("X-box Console")
product_list.append("PS-5 Console")

print("Updated List is : \n",product_list)
print("------------------------------------------------------------------------------------------")
# Extra: Convert sample_product into a list, change it price, and convert it back to tuple
sample_product = list(sample_product)       # type conversion tuple to list


sample_product[1] = 5500    # update the price from 6000 -> 5500

sample_product =tuple(sample_product)  # convert back to tuple
print("------------------------------------------------------------------------------------------")