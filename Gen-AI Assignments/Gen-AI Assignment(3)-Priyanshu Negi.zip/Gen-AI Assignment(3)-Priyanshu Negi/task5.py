# Task 5: Using filter() : Filter Expensive Products
# 1. create a list of prices greater than 500.
# 2. create another list of prices less than or equal to 500.
#  print both the lists.

prices = [100,250,400,1200,50,2000,850]

# 1. create a list of prices greater than 500.
prices_greater_500 = list(filter(lambda price:price>500,prices))

print(prices_greater_500)

# 2. create another list of prices less than or equal to 500.
prices_less_than_equal_500 = list(filter(lambda price:price<=500,prices))
print(prices_less_than_equal_500)