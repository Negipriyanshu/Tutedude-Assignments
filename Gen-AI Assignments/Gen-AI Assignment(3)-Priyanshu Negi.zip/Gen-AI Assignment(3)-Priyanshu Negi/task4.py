# Task 4: Using map(): Apply GST to list of prices
'''
Given:
prices=[100,250,400,1200,50]
Use map() with your gst lambda to generate a new list prices_with_gst.
print both list: Original prices , Prices after GST
'''
prices=[100,250,400,1200,50]
prices_with_gst =list(map(lambda price : price + (.18*price),prices))
print(f"Original Prices : {prices} \nPrice after GST : {prices_with_gst}")