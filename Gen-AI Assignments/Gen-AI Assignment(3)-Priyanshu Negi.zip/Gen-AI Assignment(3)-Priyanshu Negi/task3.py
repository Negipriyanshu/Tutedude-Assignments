# Task3 : Lambda function: GST Calculator
'''
Create  a lambda function gst that returns price after adding 18% gst.
Extra(optional) : Create another lambda to compute final price after GST + discount together
'''

gst =lambda price : price + (.18*price)
print(gst(300))

gst_with_discount =lambda price : price + (.18*price) - (.5*price)
print(gst_with_discount(300))
