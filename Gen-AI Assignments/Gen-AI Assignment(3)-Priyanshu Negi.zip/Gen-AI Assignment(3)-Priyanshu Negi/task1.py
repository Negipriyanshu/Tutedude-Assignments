# Task1 : BasicFunction : Price after Discount

# write a function apply_discount(price, discount_percent) that:
#  1. return price after dicount.
#  2. if discount_percent is missing, apply a default discount of 5%
#  3. test the function with:
#  4. apply_discount(1000,10)
#  5. apply_discount(500)
#  Extra(optional) : Add a condition inside the function to ensure discount never exceeds 60%.

def apply_discount(price, discount = 5):
    if discount <=60:
        final_price = price - ((price*discount)/100)
        return final_price

# Test the function
print(apply_discount(1000,10))
print(apply_discount(500))