# Task6: Combined Utility Function
'''
write a function process_prices(prices) that
1. takes a list of prices.
2. uses map() + lambda to apply 10% discount to all prices.
3. return both lists: discount_prices , filtered_prices

'''


def process_prices(prices):
    discounted_prices = list(map(lambda price : price - (.1*price),prices))
    filtered_prices = list(filter(lambda price : price >300,discounted_prices))
    return discounted_prices,filtered_prices


discounted_prices,filtered_prices =process_prices([100,500,900,50,750])
print("discounted prices : ",discounted_prices, "\nfiltered prices : ",filtered_prices)