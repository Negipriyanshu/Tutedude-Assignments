# Task7: Mini Problem:  Menu Using Functions
'''
create following three small functions:
1. add_price(price_list,price) -> add price to list
2. get_average_price(prices_list) -> return average price.
3. get_max_price(prices_list) -> returns the maximum price.
then create a simple menu:
1. add price
2. show average price
3. show highest price
q. quit
'''
price_list=[]

def add_price(price_list,price):
    price_list.append(price)
    

def get_average_price(price_list):
    average_price=sum(price_list)/len(price_list)
    return average_price
def get_max_price(price_list):
    max_price =max(price_list)
    return max_price

while True:
    print("1. Add Price \n2. show average price \n3. show highest price \nq. Quit")
    menu =input("Enter the menu value :\n")
    if menu == '1':
        price = int(input("Enter the prices :\n"))
        add_price(price_list,price)
        print("__________________________________")
    if menu =='2':
        print("average price is :",get_average_price(price_list))
        print("__________________________________")
    if menu == '3':
        print("Maximum price is : ",get_max_price(price_list))
        print("__________________________________")
    if menu =='q':
        print("Quit")
        print("__________________________________")
        break