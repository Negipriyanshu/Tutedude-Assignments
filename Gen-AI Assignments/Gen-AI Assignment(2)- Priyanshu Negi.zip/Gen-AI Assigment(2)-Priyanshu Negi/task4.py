# Task 5 : Loop Control with Conditions (break and Continue)
print("------------------------------------------------------------------------------------------")  

# 1. Given a list of daily sales: daily =[200,150,0,400,50,-1,300], iterate through it with a for loop and :
#   if a day's value is -1, treat it as corrupted data and break the loop
#   if a day's value is 0, treat it as a day with no sales and continue 

daily =[200,150,0,400,50,-1,300]
total_sales =0
for i in daily:
    if i ==-1:
        break
    elif i ==0:
        continue
    else:
        total_sales += i
        print("running total : ",total_sales)
print("------------------------------------------------------------------------------------------")  
# 2. Print final total after loop completes
print("total sales : ",total_sales)
print("------------------------------------------------------------------------------------------")  
