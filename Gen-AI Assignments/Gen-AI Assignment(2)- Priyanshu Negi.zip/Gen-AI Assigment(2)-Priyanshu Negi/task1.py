# Task1 : Discount Rules ( if/ elif / else)

print("------------------------------------------------------------------------------------------")
#  1. Write program that reads an integer order_amount from the user using input()

order_amount = int(input(" Enter the order amount :"))

print("------------------------------------------------------------------------------------------")
#  2. Apply the following discout rules and print the final amount:

if order_amount >=2000:
    final_amount = order_amount - (order_amount*15)/100
    print(final_amount)
elif 1500 <= order_amount <2000:
    final_amount = order_amount - (order_amount*10)/100
    print(final_amount)
elif 1000<= order_amount <1500:
    final_amount = order_amount - (order_amount*7)/100
    print(final_amount)
else:
    final_amount=order_amount
    print(final_amount)
print("------------------------------------------------------------------------------------------")

# 3. Ensure you convert input to a number and handle the case when the input is non-numeric by displaying an error message and exiting the program.
# Extra(optional):add tax (fixed 5%) after discount and price subtotal, tax, and final total
order_amount = input("Enter the order amount : ")
if order_amount.isnumeric():
    # Extra(optional)
    print("subtotal is : ",int(order_amount))
    
    tax =(int(order_amount)*5)/100
    print("tax add on : ",tax)
    
    final_amount = int(order_amount) + tax
    print("final total amount is : ",final_amount)
else:
    print("error : value is non numeric")

print("------------------------------------------------------------------------------------------")  
