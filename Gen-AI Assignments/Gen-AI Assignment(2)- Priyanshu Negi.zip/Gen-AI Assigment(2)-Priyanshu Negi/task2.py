# Task 2: Process Multiple Orders (for loop)

print("------------------------------------------------------------------------------------------")  
# 1. Given a list of order amounts: order =[1200,2500,800,1750,3000], use for loop to apply the discount rules Task1 to each order and,
# print a summary table showing: order_amount -> discont% -> final_amount

total_revenue =0 # use for 2nd task
discount_count =0
orders =[1200,2500,800,1750,3000]
for order in orders:
    if order >=2000:
        discount = 15
        discount_count +=1
    elif 1500 <= order <2000:
        discount = 10
        discount_count +=1
    elif 1000<= order <1500:
        discount = 7
        discount_count +=1
    else:
        discount =0
    
    final_amount = order -((order*discount)/100)
    total_revenue = total_revenue +final_amount
    print(f"{order} -> {discount}% -> {final_amount}")
    
print("------------------------------------------------------------------------------------------")  

# 2. Also Compute and print the total revenue after discounts
print("total revenue after discounts is : ",total_revenue)

print("------------------------------------------------------------------------------------------")  
# Extra(optional) : print the number of order that received a discount 
print("Number of order that received discount are : ",discount_count)

print("------------------------------------------------------------------------------------------")  