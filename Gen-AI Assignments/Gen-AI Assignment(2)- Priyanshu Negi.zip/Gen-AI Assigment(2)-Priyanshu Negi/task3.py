#  Task 3 : User Menu(while Loop + break/continue)

print("------------------------------------------------------------------------------------------")  

# 1. Implement a simple while-loop driven menu that keeps asking the user to choose an action until they press q to quit.
# Menu options :
#       1 -add order amount to a running list (use input())
#       2 -Show all orders and totals after applying discounts
#       q -Quit
orders = []
while True:
    print("1 -add order amount to a running list (use input()) \n 2 -Show all orders and totals after applying discounts \n q -Quit")
    num = input("Enter the Menu option")
    if num == "1":
        orders.append(int(input(" Enter the order amount :")))
    elif num == "2":
        for order in orders:
            if order >=2000:
                discount = 15   
            elif 1500 <= order <2000:
                discount = 10
            elif 1000<= order <1500:
                discount = 7
            else:
                discount =0
            final_amount = order -((order*discount)/100)
            print(f"{order} -> {discount}% -> {final_amount}")
    elif num == "q":
        print("Quit")
        break       #2nd: exit if enter "q"
    else:           #2nd: if invalid input is entered
        continue
print("------------------------------------------------------------------------------------------")  
