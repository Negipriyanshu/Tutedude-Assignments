# Task3: Python Functionalities on Series
import pandas as pd

marks =[78,85,90,66,72]
marksSeries = pd.Series(marks)

print("Maximum Marks : ",marksSeries.max())
print("Minimum Marks : ",marksSeries.min())
print("Sum of Marks : ",marksSeries.sum())
print("Mean of Marks : ",marksSeries.mean())


pass_student = list(filter(lambda mark : mark>=70,marksSeries))
print("No. of Student Passed : ",len(pass_student))