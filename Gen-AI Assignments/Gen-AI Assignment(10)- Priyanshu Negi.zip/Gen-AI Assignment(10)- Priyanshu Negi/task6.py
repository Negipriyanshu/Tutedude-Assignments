# Task6: Filtering & Conditional Selection
import pandas as pd

students ={'Name': ['Amrit','Neha','Rahul','Sneha','Pooja'],
           'Marks':[78,85,90,66,72],
           'Subject':['Math','Math','Science','Science','Math']
           }

data =pd.DataFrame(data=students)

print("Student who score more than 75 marks\n",data[data['Marks']>75])
print("Student who belongs to Maths\n",data[data['Subject']=='Math'])
print("Students Who Scores more than Average\n",data[data['Marks']>data['Marks'].mean()])
print("Students who failed (marks <70)\n",data[data['Marks']<70])