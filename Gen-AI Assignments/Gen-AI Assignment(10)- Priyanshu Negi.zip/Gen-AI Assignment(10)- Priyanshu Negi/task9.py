# Task9: Mini Use Case: Sales Data Analysis
import pandas as pd
import matplotlib.pyplot as plt
sales={
    'Day':['Mon','Tue','Wed','Thu','Fri'],
    'Revenue':[1200,1500,900,2000,1800]
}

sales_df=pd.DataFrame(data =sales)
print("Total Revenue : ",sales_df['Revenue'].sum())
print('Average Daily Revenue : ',sales_df['Revenue'].mean())
print("Day with Highest Revenue",sales_df.groupby('Day')['Revenue'].max())
print("Days Where Revenue is higher than average\n",sales_df[sales_df['Revenue']>sales_df['Revenue'].mean()])
sales_df.plot(x='Day',y='Revenue')
plt.show()