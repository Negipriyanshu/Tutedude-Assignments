# Task7: Grouping & Basic Analysis
import pandas as pd

students ={'Name': ['Amrit','Neha','Rahul','Sneha','Pooja'],
           'Marks':[78,85,90,66,72],
           'Subject':['Math','Math','Science','Science','Math']
           }

data =pd.DataFrame(data=students)

mean_subcat_data = data[data['Marks']>data['Marks'].mean()].groupby('Subject')
for subject , group in mean_subcat_data:
    print("Subject : ",subject)
    print(group)
    
print(data.groupby('Subject').size())

print(data.groupby('Subject').agg(
    max_Marks=('Marks','max')
))