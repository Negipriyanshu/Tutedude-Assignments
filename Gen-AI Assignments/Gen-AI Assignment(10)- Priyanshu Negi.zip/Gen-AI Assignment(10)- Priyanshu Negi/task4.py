# Task4: Create a DataFrame
import pandas as pd

students ={'Name': ['Amrit','Neha','Rahul','Sneha','Pooja'],
           'Marks':[78,85,90,66,72],
           'Subject':['Math','Math','Science','Science','Math']
           }
data =pd.DataFrame(data=students)
print("First 3 rows \n",data.head(3))
print("Botttom 2 rows\n",data.tail(2))
print("Dimension of Dataframe : ",data.shape ,"\nColumns Name : ",data.columns)