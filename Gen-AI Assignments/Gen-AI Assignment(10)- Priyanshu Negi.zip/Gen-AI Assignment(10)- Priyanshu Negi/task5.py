# Task5: Important DataFrame Functions
import pandas as pd

students ={'Name': ['Amrit','Neha','Rahul','Sneha','Pooja'],
           'Marks':[78,85,90,66,72],
           'Subject':['Math','Math','Science','Science','Math']
           }

data =pd.DataFrame(data=students)

print(data.info())
print(data.describe())
print(data.head())
print(data.tail())
sort_data =data.sort_values(by='Marks',ascending =False)
print(sort_data.reset_index())
