# Task8: Pandas Plotting (Simple Graphs)
import pandas as pd 
import matplotlib.pyplot as plt
students ={'Name': ['Amrit','Neha','Rahul','Sneha','Pooja'],
           'Marks':[78,85,90,66,72],
           'Subject':['Math','Math','Science','Science','Math']
           }

data =pd.DataFrame(data=students)
data.plot(x='Name',y='Marks',kind ='bar')
plt.show()

data.plot(x='Name',y='Marks',kind ='line')
plt.show()

data.plot(x='Name',y='Marks',kind ='hist')
plt.show()