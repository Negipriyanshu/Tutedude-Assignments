# Task1: Pandas Series Basics

import pandas as pd

marks =[78,85,90,66,72]
marksSeries = pd.Series(marks)

print(f"Series Values: {marksSeries.values}\nIndex: {marksSeries.index}\nData Type: {marksSeries.dtype}\n ")
print(f"First Element: {marksSeries[0]}\nLast Two elements: {marksSeries[-2::].values}")