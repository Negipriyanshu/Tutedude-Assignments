# Task2: Mathematical Operations on Series
import pandas as pd

marks =[78,85,90,66,72]
marksSeries = pd.Series(marks)
# gracing 5 marks to Series
grace5= marksSeries+5
sub2=marksSeries-2
multi1_05=marksSeries*1.05
divideby2=marksSeries/2
print(f"5+ graces : {grace5.values}\n2 subtract : {sub2.values}\n1.05multi : {multi1_05.values}\nDivide by 2 : {divideby2.values}")