# Task3: Product form (app_product_form.py)

import streamlit as st

product_list =[("Product name ","Category","Price")]
name= st.sidebar.text_input("Enter Product Name")
category = st.sidebar.selectbox("Select Category Name",["Electronics","Dairy Product","Digital Product","Wood Product","Grocery","Stationary"])
price = st.sidebar.number_input("Enter the price of product")

product_list.append((name,category,str(price)))
if st.sidebar.button("Add Product"):
    st.success("Product is added to cart")
    st.table(data=product_list)