# Task4: Mini Dashboard (app_dashboard.py)

import streamlit as st

st.title("Dashboard")
st.subheader("Simple Sales Dashboard")

month = st.selectbox("Select the Month",["January","Febuary","March","April"])

sales ={
    "January":1200,
    "Febuary":1500,
    "March":900,
    "April":2000
}

st.write(f"{month} month has {sales[month]} sales")

st.bar_chart((list(sales.values())))