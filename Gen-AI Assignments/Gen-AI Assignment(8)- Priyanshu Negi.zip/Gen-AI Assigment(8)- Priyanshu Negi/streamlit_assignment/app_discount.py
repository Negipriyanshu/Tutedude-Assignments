# Task2: Price Calculator (app_discount.py) 

import streamlit as st

price =st.number_input("Enter the product Price")
discount = st.slider("Discount :",0,50,10)
discounted_price = price - price*discount*.01
if st.button("Calculate"):
    st.success(discounted_price)
    data = [
    ("before","after"),
    (price,discounted_price)
    ]
    st.table(data)
