# Task1: Basic Streamlit app(app_basic.py)

import streamlit as st


st.title("Welcome to Streamlit!")
name=st.text_input("Enter Your Name : ")

if st.button("Greet Me"):
    st.write(f"Hello, {name}!")