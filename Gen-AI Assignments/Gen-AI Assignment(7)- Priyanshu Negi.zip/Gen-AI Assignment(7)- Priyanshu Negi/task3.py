#  Task3: Single level Inheritance

class Product:
    def __init__(self,name,price,category):
        self.name=name
        self.price=price
        self.category =category
    
    def get_info(self):
        return f"Product name : {self.name}\nCategory name : {self.category}\nPrice :{self.price}"

class ElectronicProduct(Product):
    def __init__(self,name,price,warranty,category="Electronic"):
        super().__init__(name,price,category)
        self.warranty =warranty
    
    def get_info(self):
        return f"Product name : {self.name}\nCategory name : {self.category}\nPrice :{self.price}\nwarranty info : {self.warranty}"

product1 =Product("Shampoo",200,"Daily-care")
product2=ElectronicProduct("A.C",50000,"5years")

print(product1.get_info())
print(product2.get_info())