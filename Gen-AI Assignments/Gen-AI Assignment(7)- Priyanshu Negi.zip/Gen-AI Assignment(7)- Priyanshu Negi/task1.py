# Task1: Basic Class & Object Creation
class Product:
    def __init__(self,name,price,category):
        self.name =name
        self.price =price
        self.category = category
    def get_info(self):
        print(f"Product name : {self.name}\nCategory : {self.category}\nPrice : {self.price}")
        
    def apply_discount(self,percentage):
        return self.price - (self.price*percentage*.01)

product1 = Product("Atta",350,"Ration")
product1.get_info()
print(product1.apply_discount(10))