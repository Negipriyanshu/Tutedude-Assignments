# Task2: Constructor & Encapsulation

class Product:
    def __init__(self,name,price,category):
        self.name =name
        self.__price =price
        self.category = category

    def get_price(self):            # getter method
        return self.__price
    
    def set_price(self,new_price):      # setter method
        if new_price>0:
            self.__price =new_price
            print("Price is updated")
product=Product("PS5",40000,"Gaming Console")

print("Product Price : ",product.get_price())


product.set_price(45000)
print("New Price of Product :",product.get_price())