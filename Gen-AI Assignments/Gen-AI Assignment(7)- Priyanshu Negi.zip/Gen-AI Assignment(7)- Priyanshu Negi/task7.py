# Task7: Mini Project: Simple Inventory System (OOPs Only)
class Inventory:
    def __init__(self):
        self.products =[] # list of dictionaries
        
    def add_product(self,name,price):
        self.products.append({
            "name":name,
            "price":price
        })        
    
    def remove_product(self,name):
        for product in self.products:
            if product["name"] == name:
                self.products.remove(product) 
                return f"Product has been removed..."
    
    def get_total_value(self):
        sum=0
        for product in self.products:
            sum =sum + product["price"]
        return sum
    
    def show_all_products(self):
        for product in self.products:
            print(f"product Name : {product['name']}\t Price : {product['price']}\n")

class Store:
    
    def __init__(self,store_name):
        self.store_name =store_name
        self.inventory =Inventory()
    
    
    def add_new_product(self):
        name= input("Enter the Product name :\n")
        price =float(input("Enter the price :\n"))
        
        self.inventory.add_product(name,price)
        
    
    def show_summary(self):
        print("\nStore:", self.store_name)
        print("Total Items:", len(self.inventory.products))
        print("Total Value: ₹", self.inventory.get_total_value())
    
store1 =Store("Tech Super Mart")
store1.add_new_product()
store1.add_new_product()
store1.add_new_product()
store1.show_summary()
    