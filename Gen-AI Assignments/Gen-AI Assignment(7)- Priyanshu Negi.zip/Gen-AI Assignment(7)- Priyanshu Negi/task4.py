# Task4: Polymorphism
class Product:
    def __init__(self,name,price,category):
        self.name=name
        self.price =price
        self.category =category
        
    def get_info(self):
        return f"Product name : {self.name}\nCategory name : {self.category}\nPrice : {self.price}"
    
class Laptop(Product):
    def __init__(self,name,price,category="Laptop"):
        super().__init__(name,price,category)
    
    def get_info(self):
        return f"Product name : {self.name}\nCategory name : {self.category}\nPrice : {self.price}"

class Mobile(Product):
    def __init__(self,name,price,category="Mobile"):
        super().__init__(name,price,category)
    
    def get_info(self):
        return f"Product name : {self.name}\nCategory name : {self.category}\nPrice : {self.price}"
    
laptop1 =Laptop("ASUS",50000)
mobile1 =Mobile("Iphone15",70000)
products =[laptop1,mobile1]

for product in products:
    print(product.get_info())