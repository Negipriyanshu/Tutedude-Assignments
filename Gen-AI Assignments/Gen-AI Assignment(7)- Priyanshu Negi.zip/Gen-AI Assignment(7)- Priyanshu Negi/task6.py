# Task6: Magic Methods & Operator Overloading
class Product:
    def __init__(self,name,price,category) -> None:
        self.name=name
        self.price =price
        self.category =category
    
    # Dunder methods
    def __add__(self,other):
        return Product(f"{self.name} & {other.name}",self.price + other.price,f"{self.category} & {other.category}" )
    
    def __str__(self):
        return f"Product name :{self.name}\n Price :{self.price}\nCategory : {self.category}"
    
product1 =Product("A.C",80000,"Room Ess.")
product2 = Product("Mac book",60000,"Laptop")

product = product1 + product2
print(f"Total Price : {product.price}")