# Task5: Abstraction (Using Abstract Base Class)
from abc import ABC,abstractmethod

class Payment(ABC):
    def __init__(self,amount):
        self.amount =amount
    
    @abstractmethod
    def process_payment(self):
        pass
    
class CreditCardPayment(Payment):
    def __init__(self, amount):
        super().__init__(amount)
        
    def process_payment(self):
        print(f"Statement\n{self.amount}")
        
class UPIPayment(Payment):
    def __init__(self, amount):
        super().__init__(amount)
        
    def process_payment(self):
        print(f"Statement\n{self.amount}")


# Cannot create object of abstract class
# trans1 =Payment(5000)
# trans1.process_payment()

trans2=CreditCardPayment(10000)
trans2.process_payment()

trans3 = UPIPayment(500)
trans3.process_payment()